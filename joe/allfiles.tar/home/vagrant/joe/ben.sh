echo "enter variable 1"
read value1
echo "enter variable 2"
read value2
if  [ $value1 == $value2 ]
then
	tar -cvf allfiles.tar /home/vagrant/joe
	git add allfiles.tar
	git commit -m "archive file"
	git push origin main
else
	echo "values not equal; pushing all files to develop"
fi

