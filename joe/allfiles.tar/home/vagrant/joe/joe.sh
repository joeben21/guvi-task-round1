for text in {a..j}
do
	echo welcome > "$text.txt"
done

